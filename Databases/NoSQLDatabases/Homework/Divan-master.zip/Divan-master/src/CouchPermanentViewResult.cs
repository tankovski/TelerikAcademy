namespace Divan
{
    /// <summary>
    /// This is a view result from a CouchQuery on a permanent CouchDB view.
    /// </summary>
    public class CouchPermanentViewResult : CouchViewResult
    {
    }
}