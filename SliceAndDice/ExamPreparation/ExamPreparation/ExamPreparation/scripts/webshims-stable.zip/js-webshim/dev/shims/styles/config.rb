# compass config

http_path = "/"
css_dir = "/"
sass_dir = "scss"
images_dir = "/"
javascripts_dir = "/"

# output_style = :expanded or :nested or :compact or :compressed
output_style = :expanded
relative_assets = true
line_comments = false